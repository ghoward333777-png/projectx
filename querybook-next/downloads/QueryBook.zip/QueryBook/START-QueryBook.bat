@echo off
rem QueryBook Next - double-click to start. Python is included in the python folder.
cd /d "%~dp0"
"%~dp0python\python.exe" "%~dp0querybook-next.pyz" %*
if errorlevel 1 pause
