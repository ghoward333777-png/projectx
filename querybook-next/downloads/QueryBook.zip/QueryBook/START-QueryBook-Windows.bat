@echo off
cd /d "%~dp0"
where py >nul 2>nul && (py -3 querybook-next.pyz) || (python querybook-next.pyz)
if errorlevel 1 (
  echo.
  echo If this window says Python was not found: install Python from https://www.python.org/downloads/
  echo and tick "Add python.exe to PATH". Then double-click this file again.
  pause
)
