@echo off
rem QueryBook - double-click to start every application in one window. Python is included (python folder).
title QueryBook
cd /d "%~dp0"
"%~dp0python\python.exe" -X utf8 "%~dp0QueryBook-Shell\shell.py" %*
if errorlevel 1 pause
