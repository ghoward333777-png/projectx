#!/bin/bash
# QueryBook - double-click to start (first time: right-click > Open > Open).
cd "$(dirname "$0")"
exec python3 QueryBook-Shell/shell.py "$@"
