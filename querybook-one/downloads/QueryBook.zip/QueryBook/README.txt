QueryBook
=========

1. Unzip this file (right-click > Extract All).
2. Close the old QueryBook windows if they are open (they use the same data and the same ports).
3. Open the QueryBook folder and double-click START-QueryBook.bat
4. Your browser opens QueryBook: every application in one window. Keep the black window open while you use it.

Your data stays on D:\QB (data-folder.txt). If the drive is not connected, nothing starts.
Python is included for Windows - nothing to install. On a Mac, double-click START-QueryBook.command (needs python3).
