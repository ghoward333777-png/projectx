"""QueryBook bundle: put the running script's folder first on sys.path, as a normal Python install does."""
import os, sys
if sys.argv and sys.argv[0] and sys.argv[0].endswith('.py') and os.path.isfile(sys.argv[0]):
    sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0])))
